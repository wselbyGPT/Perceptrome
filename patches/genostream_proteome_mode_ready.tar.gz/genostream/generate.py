import logging, os, random
from typing import List, Optional

import numpy as np

try:
    import torch
except ImportError:
    torch = None  # type: ignore

from .config import TrainingConfig, IOConfig
from .model import get_device, load_or_init_model
from .encoding import tokenizer_meta, IDX_TO_CODON, CODON_VOCAB_SIZE, GC_COUNT_PER_TOKEN, IDX_TO_AA, AA_VOCAB_SIZE

def _sample_index(weights: np.ndarray, temperature: float) -> int:
    w = weights.astype(np.float64)
    w = np.clip(w, 1e-9, None)
    temperature = max(1e-3, float(temperature))
    if temperature != 1.0:
        w = w ** (1.0 / temperature)
    s = w.sum()
    if s <= 0:
        return int(np.random.randint(0, w.shape[0]))
    w /= s
    return int(np.random.choice(w.shape[0], p=w))

def generate_plasmid_sequence(
    train_cfg: TrainingConfig,
    io_cfg: IOConfig,
    length_bp: int,
    num_windows: Optional[int],
    window_size_bp: int,
    seed: Optional[int],
    latent_scale: float,
    temperature: float,
    gc_bias: float,
    name: str,
    output_path: str,
    tokenizer: str,
) -> str:
    if torch is None:
        raise RuntimeError("PyTorch not installed.")
    tok = tokenizer.lower()
    if tok not in ("base", "codon"):
        raise ValueError("generate_plasmid_sequence only supports base|codon")

    if tok == "codon" and length_bp % 3 != 0:
        length_bp = (length_bp // 3) * 3

    if seed is not None:
        np.random.seed(seed); random.seed(seed); torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    device = get_device()
    seq_len, vocab_size = tokenizer_meta(tok, window_size_bp)
    hidden_dim = train_cfg.hidden_dim

    model, optimizer, global_step, ckpt_path = load_or_init_model(
        io_cfg=io_cfg,
        seq_len=seq_len,
        vocab_size=vocab_size,
        hidden_dim=hidden_dim,
        learning_rate=train_cfg.learning_rate,
        device=device,
        tokenizer=tok,
    )
    model.eval()

    if num_windows is not None:
        n_windows = int(num_windows)
        target_bp = n_windows * window_size_bp
    else:
        n_windows = (length_bp + window_size_bp - 1) // window_size_bp
        target_bp = length_bp

    temperature = float(temperature)
    latent_scale = float(latent_scale)
    gc_bias = float(gc_bias)

    seq_parts: List[str] = []

    with torch.no_grad():
        for _ in range(n_windows):
            z = torch.randn(1, hidden_dim, device=device) * latent_scale
            recon_flat = model.decode(z)   # (1, seq_len*vocab)
            recon = recon_flat.view(seq_len, vocab_size).cpu().numpy()

            if tok == "base":
                idx_to_base = ["A", "C", "G", "T"]
                for j in range(seq_len):
                    w = recon[j].copy()
                    # apply gc bias to C/G
                    if gc_bias != 1.0:
                        w[1] *= gc_bias
                        w[2] *= gc_bias
                    idx = _sample_index(w, temperature)
                    seq_parts.append(idx_to_base[idx])
            else:
                for j in range(seq_len):
                    w = recon[j].copy()
                    if gc_bias != 1.0:
                        w *= (gc_bias ** GC_COUNT_PER_TOKEN[: w.shape[0]])
                    idx = _sample_index(w, temperature)
                    seq_parts.append(IDX_TO_CODON[idx])

    seq = "".join(seq_parts)
    seq = seq[:target_bp]

    out_dir = os.path.dirname(output_path) or "."
    os.makedirs(out_dir, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(f">{name}\n")
        for i in range(0, len(seq), 60):
            f.write(seq[i:i+60] + "\n")

    return seq

def generate_protein_sequence(
    train_cfg: TrainingConfig,
    io_cfg: IOConfig,
    length_aa: int,
    num_windows: Optional[int],
    window_aa: int,
    seed: Optional[int],
    latent_scale: float,
    temperature: float,
    name: str,
    output_path: str,
) -> str:
    if torch is None:
        raise RuntimeError("PyTorch not installed.")

    if seed is not None:
        np.random.seed(seed); random.seed(seed); torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    device = get_device()
    tok = "aa"
    seq_len, vocab_size = tokenizer_meta(tok, window_aa)
    assert vocab_size == AA_VOCAB_SIZE
    hidden_dim = train_cfg.hidden_dim

    model, optimizer, global_step, ckpt_path = load_or_init_model(
        io_cfg=io_cfg,
        seq_len=seq_len,
        vocab_size=vocab_size,
        hidden_dim=hidden_dim,
        learning_rate=train_cfg.learning_rate,
        device=device,
        tokenizer=tok,
    )
    model.eval()

    if num_windows is not None:
        n_windows = int(num_windows)
        target_aa = n_windows * window_aa
    else:
        n_windows = (length_aa + window_aa - 1) // window_aa
        target_aa = length_aa

    temperature = float(temperature)
    latent_scale = float(latent_scale)

    aa_chars: List[str] = []

    with torch.no_grad():
        for _ in range(n_windows):
            z = torch.randn(1, hidden_dim, device=device) * latent_scale
            recon_flat = model.decode(z)
            recon = recon_flat.view(seq_len, vocab_size).cpu().numpy()

            for j in range(seq_len):
                idx = _sample_index(recon[j], temperature)
                aa_chars.append(IDX_TO_AA[idx])

    seq = "".join(aa_chars)[:target_aa]

    out_dir = os.path.dirname(output_path) or "."
    os.makedirs(out_dir, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(f">{name}\n")
        for i in range(0, len(seq), 60):
            f.write(seq[i:i+60] + "\n")

    return seq
