import logging, os
from typing import Dict, Any

import numpy as np

try:
    import torch
    from torch.utils.data import DataLoader, TensorDataset
except ImportError:
    torch = None  # type: ignore
    DataLoader = None  # type: ignore
    TensorDataset = None  # type: ignore

from .config import IOConfig, TrainingConfig
from .model import get_device, load_or_init_model, save_checkpoint, vae_loss
from .encoding import tokenizer_meta

def train_on_encoded(
    accession: str,
    encoded: np.ndarray,
    steps: int,
    batch_size: int,
    state: Dict[str, Any],
    io_cfg: IOConfig,
    train_cfg: TrainingConfig,
    tokenizer: str,
    window_size_bp: int,
) -> float:
    if torch is None:
        raise RuntimeError("PyTorch not installed.")
    device = get_device()

    seq_len, vocab_size = tokenizer_meta(tokenizer, window_size_bp)
    hidden_dim = train_cfg.hidden_dim

    model, optimizer, global_step, ckpt_path = load_or_init_model(
        io_cfg=io_cfg,
        seq_len=seq_len,
        vocab_size=vocab_size,
        hidden_dim=hidden_dim,
        learning_rate=train_cfg.learning_rate,
        device=device,
        tokenizer=tokenizer,
    )

    windows_tensor = torch.from_numpy(encoded)  # (N, L, V)
    dataset = TensorDataset(windows_tensor)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=False)

    if len(dataloader) == 0:
        logging.warning(f"{accession}: no windows to train on (shape={encoded.shape})")
        return 0.0

    logging.info(
        f"{accession}: train tokenizer={tokenizer} windows={encoded.shape[0]} "
        f"L={encoded.shape[1]} V={encoded.shape[2]} steps={steps} batch={batch_size}"
    )

    step_count = 0
    last_total = 0.0
    it = iter(dataloader)

    while step_count < steps:
        try:
            (batch,) = next(it)
        except StopIteration:
            it = iter(dataloader)
            (batch,) = next(it)

        batch = batch.to(device)         # (B, L, V)
        x_flat = batch.view(batch.size(0), -1)

        if train_cfg.kl_warmup_steps > 0:
            warm = min(1.0, (global_step + 1) / float(train_cfg.kl_warmup_steps))
            beta = train_cfg.beta_kl * warm
        else:
            beta = train_cfg.beta_kl

        optimizer.zero_grad(set_to_none=True)
        recon_flat, mu, logvar = model(x_flat)
        total, recon, kl = vae_loss(recon_flat, x_flat, mu, logvar, beta)
        total.backward()

        if train_cfg.max_grad_norm and train_cfg.max_grad_norm > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), train_cfg.max_grad_norm)

        optimizer.step()

        step_count += 1
        global_step += 1
        last_total = float(total.item())

        if step_count % 10 == 0 or step_count == steps:
            logging.info(
                f"{accession}: step {step_count}/{steps} total={total.item():.6f} recon={recon.item():.6f} kl={kl.item():.6f} beta={beta:.3g}"
            )

    state["total_steps"] = int(state.get("total_steps", 0)) + step_count

    save_checkpoint(
        ckpt_path=ckpt_path,
        model=model,
        optimizer=optimizer,
        global_step=global_step,
        tokenizer=tokenizer,
        seq_len=seq_len,
        vocab_size=vocab_size,
        hidden_dim=hidden_dim,
    )

    return last_total

def cleanup_accession_files(accession: str, io_cfg: IOConfig, encoded_path: str) -> None:
    fasta_path = os.path.join(io_cfg.cache_fasta_dir, f"{accession}.fasta")
    for path in (fasta_path, encoded_path):
        if os.path.exists(path):
            try:
                os.remove(path)
                logging.info(f"{accession}: deleted {path}")
            except OSError as e:
                logging.warning(f"{accession}: failed to delete {path}: {e}")

def compute_window_errors(
    accession: str,
    encoded: np.ndarray,
    io_cfg: IOConfig,
    train_cfg: TrainingConfig,
    tokenizer: str,
    window_size_bp: int,
) -> np.ndarray:
    if torch is None:
        raise RuntimeError("PyTorch not installed.")
    device = get_device()

    seq_len, vocab_size = tokenizer_meta(tokenizer, window_size_bp)
    hidden_dim = train_cfg.hidden_dim

    model, optimizer, global_step, ckpt_path = load_or_init_model(
        io_cfg=io_cfg,
        seq_len=seq_len,
        vocab_size=vocab_size,
        hidden_dim=hidden_dim,
        learning_rate=train_cfg.learning_rate,
        device=device,
        tokenizer=tokenizer,
    )

    model.eval()
    with torch.no_grad():
        wt = torch.from_numpy(encoded).to(device)
        if wt.numel() == 0:
            return np.zeros((0,), dtype=np.float32)
        N = wt.size(0)
        x_flat = wt.view(N, -1)
        mu, logvar = model.encode(x_flat)
        recon_flat = model.decode(mu)
        recon = recon_flat.view_as(wt)
        mse = (recon - wt).pow(2).mean(dim=(1, 2))
        return mse.cpu().numpy().astype(np.float32)
