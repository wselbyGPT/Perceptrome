#!/usr/bin/env python3
import argparse, logging, os
from typing import Any

import numpy as np

from .config import extract_configs, load_full_config
from .encoding import compute_gc_from_encoded, encode_accession
from .generate import generate_plasmid_sequence, generate_protein_sequence
from .io_utils import ensure_dirs, load_state, read_catalog, save_state, setup_logging, encoded_cache_path
from .ncbi_fetch import fetch_fasta
from .training import cleanup_accession_files, compute_window_errors, train_on_encoded

try:
    import curses
except ImportError:
    curses = None  # type: ignore

from .scope import run_scope_ui, run_scope_stream_ui, ScopeStreamContext

def _get_tok(args, train_cfg):
    return (getattr(args, "tokenizer", None) or train_cfg.tokenizer).lower()

def _get_frame(args, train_cfg):
    return int(getattr(args, "frame_offset", None) if getattr(args, "frame_offset", None) is not None else train_cfg.frame_offset)

def _get_min_orf(args, train_cfg):
    v = getattr(args, "min_orf_aa", None)
    return int(v if v is not None else train_cfg.min_orf_aa)

def _pick_window_stride(args, train_cfg, tok: str):
    if tok == "aa":
        w = args.window_size if args.window_size is not None else train_cfg.protein_window_aa
        s = args.stride if args.stride is not None else train_cfg.protein_stride_aa
    else:
        w = args.window_size if args.window_size is not None else train_cfg.window_size
        s = args.stride if args.stride is not None else train_cfg.stride
    return int(w), int(s)

def _validate_tok_params(tokenizer: str, window_size: int, stride: int, frame: int):
    if tokenizer == "codon":
        if window_size % 3 != 0:
            raise ValueError(f"--tokenizer codon requires window_size divisible by 3 (got {window_size})")
        if stride % 3 != 0:
            raise ValueError(f"--tokenizer codon requires stride divisible by 3 (got {stride})")
        if frame not in (0,1,2):
            raise ValueError("--frame-offset must be 0,1,2")
    elif tokenizer == "aa":
        if window_size <= 0 or stride <= 0:
            raise ValueError("--tokenizer aa requires positive --window-size/--stride (amino acids)")
    else:
        if window_size <= 0 or stride <= 0:
            raise ValueError("window_size/stride must be positive")

def cmd_init(args: argparse.Namespace) -> int:
    cfg = load_full_config(args.config)
    _, _, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg)
    setup_logging(io_cfg.logs_dir)
    state = {"current_index": 0, "total_steps": 0, "plasmid_visit_counts": {}, "epoch": 0, "last_checkpoint": None}
    save_state(io_cfg.state_file, state)
    print(f"Initialized project. State file at: {io_cfg.state_file}")
    return 0

def cmd_catalog_show(args: argparse.Namespace) -> int:
    accessions = read_catalog(args.path)
    print(f"Catalog: {args.path}\n  {len(accessions)} accessions")
    for acc in accessions[:10]:
        print(f"    {acc}")
    if len(accessions) > 10:
        print(f"    ... (+{len(accessions)-10} more)")
    return 0

def cmd_fetch_one(args: argparse.Namespace) -> int:
    cfg = load_full_config(args.config)
    ncbi_cfg, train_cfg, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg); setup_logging(io_cfg.logs_dir)
    fetch_fasta(args.accession, io_cfg, ncbi_cfg, force=args.force)
    return 0

def cmd_encode_one(args: argparse.Namespace) -> int:
    cfg = load_full_config(args.config)
    _, train_cfg, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg); setup_logging(io_cfg.logs_dir)

    tok = _get_tok(args, train_cfg)
    frame = _get_frame(args, train_cfg)
    min_orf = _get_min_orf(args, train_cfg)
    window_size, stride = _pick_window_stride(args, train_cfg, tok)
    _validate_tok_params(tok, window_size, stride, frame)

    fasta_path = os.path.join(io_cfg.cache_fasta_dir, f"{args.accession}.fasta")
    if not os.path.exists(fasta_path):
        print(f"FASTA for {args.accession} not found at {fasta_path}. Run fetch-one first.")
        return 1

    out_path = encoded_cache_path(io_cfg, args.accession, tok, window_size, stride, frame, min_orf_aa=(min_orf if tok=="aa" else None))
    encoded = encode_accession(
        args.accession, io_cfg, window_size, stride,
        tokenizer=tok, frame_offset=frame, min_orf_aa=min_orf,
        save_to_disk=True, out_path=out_path
    )
    print(f"{args.accession}: encoded tokenizer={tok} -> shape={encoded.shape} saved={out_path}")
    return 0

def cmd_train_one(args: argparse.Namespace) -> int:
    cfg = load_full_config(args.config)
    ncbi_cfg, train_cfg, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg); setup_logging(io_cfg.logs_dir)
    state = load_state(io_cfg.state_file)

    tok = _get_tok(args, train_cfg)
    frame = _get_frame(args, train_cfg)
    min_orf = _get_min_orf(args, train_cfg)
    window_size, stride = _pick_window_stride(args, train_cfg, tok)
    _validate_tok_params(tok, window_size, stride, frame)

    batch_size = args.batch_size or train_cfg.batch_size
    steps = args.steps or train_cfg.steps_per_plasmid

    fasta_path = os.path.join(io_cfg.cache_fasta_dir, f"{args.accession}.fasta")
    if not os.path.exists(fasta_path):
        logging.info(f"{args.accession}: FASTA not found; fetching.")
        fetch_fasta(args.accession, io_cfg, ncbi_cfg, force=False)

    enc_path = encoded_cache_path(io_cfg, args.accession, tok, window_size, stride, frame, min_orf_aa=(min_orf if tok=="aa" else None))
    if os.path.exists(enc_path) and not args.reencode:
        encoded = np.load(enc_path)
        logging.info(f"{args.accession}: using cached encoded at {enc_path} shape={encoded.shape}")
    else:
        encoded = encode_accession(
            args.accession, io_cfg, window_size, stride,
            tokenizer=tok, frame_offset=frame, min_orf_aa=min_orf,
            save_to_disk=True, out_path=enc_path
        )

    last_total = train_on_encoded(
        args.accession, encoded,
        steps=steps, batch_size=batch_size,
        state=state, io_cfg=io_cfg, train_cfg=train_cfg,
        tokenizer=tok, window_size_bp=window_size,  # "units" for aa, ok
    )

    pvc = state["plasmid_visit_counts"]
    pvc[args.accession] = pvc.get(args.accession, 0) + 1
    save_state(io_cfg.state_file, state)

    print(f"{args.accession}: train-one tokenizer={tok} steps={steps} batch={batch_size} last_total={last_total:.6f}")
    return 0

def cmd_scope_one(args: argparse.Namespace) -> int:
    if curses is None:
        raise RuntimeError("curses not available")
    cfg = load_full_config(args.config)
    _, train_cfg, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg); setup_logging(io_cfg.logs_dir)

    tok = _get_tok(args, train_cfg)
    frame = _get_frame(args, train_cfg)
    min_orf = _get_min_orf(args, train_cfg)
    window_size, stride = _pick_window_stride(args, train_cfg, tok)
    _validate_tok_params(tok, window_size, stride, frame)

    enc_path = encoded_cache_path(io_cfg, args.accession, tok, window_size, stride, frame, min_orf_aa=(min_orf if tok=="aa" else None))
    if os.path.exists(enc_path) and not args.reencode:
        encoded = np.load(enc_path)
    else:
        encoded = encode_accession(
            args.accession, io_cfg, window_size, stride,
            tokenizer=tok, frame_offset=frame, min_orf_aa=min_orf,
            save_to_disk=True, out_path=enc_path
        )

    errors = compute_window_errors(args.accession, encoded, io_cfg=io_cfg, train_cfg=train_cfg, tokenizer=tok, window_size_bp=window_size)
    metric = compute_gc_from_encoded(encoded, tokenizer=tok)  # for aa: hydrophobic fraction

    curses.wrapper(
        run_scope_ui,
        accession=args.accession,
        errors=errors,
        gc_values=metric,
        window_size=window_size,
        stride=stride,
        fps=args.fps,
    )
    return 0

def cmd_scope_stream(args: argparse.Namespace) -> int:
    if curses is None:
        raise RuntimeError("curses not available")
    cfg = load_full_config(args.config)
    _, train_cfg, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg); setup_logging(io_cfg.logs_dir)

    tok = _get_tok(args, train_cfg)
    frame = _get_frame(args, train_cfg)
    min_orf = _get_min_orf(args, train_cfg)
    window_size, stride = _pick_window_stride(args, train_cfg, tok)
    _validate_tok_params(tok, window_size, stride, frame)

    steps = args.steps or train_cfg.steps_per_plasmid
    batch_size = args.batch_size or train_cfg.batch_size

    enc_path = encoded_cache_path(io_cfg, args.accession, tok, window_size, stride, frame, min_orf_aa=(min_orf if tok=="aa" else None))
    if os.path.exists(enc_path) and not args.reencode:
        encoded = np.load(enc_path)
    else:
        encoded = encode_accession(
            args.accession, io_cfg, window_size, stride,
            tokenizer=tok, frame_offset=frame, min_orf_aa=min_orf,
            save_to_disk=True, out_path=enc_path
        )

    metric = compute_gc_from_encoded(encoded, tokenizer=tok)

    import torch
    from torch.utils.data import DataLoader, TensorDataset
    from .model import get_device, load_or_init_model
    from .encoding import tokenizer_meta

    device = get_device()
    seq_len, vocab_size = tokenizer_meta(tok, window_size)
    hidden_dim = train_cfg.hidden_dim

    model, optimizer, global_step, ckpt_path = load_or_init_model(
        io_cfg=io_cfg, seq_len=seq_len, vocab_size=vocab_size,
        hidden_dim=hidden_dim, learning_rate=train_cfg.learning_rate,
        device=device, tokenizer=tok
    )

    windows_tensor = torch.from_numpy(encoded)
    dataset = TensorDataset(windows_tensor)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=False)

    ctx = ScopeStreamContext(
        model=model, optimizer=optimizer, device=device,
        dataloader=dataloader, dataloader_iter=iter(dataloader),
        global_step=global_step, last_total=0.0,
        steps_target=steps, steps_done=0,
        beta_kl=train_cfg.beta_kl, kl_warmup_steps=train_cfg.kl_warmup_steps,
        max_grad_norm=train_cfg.max_grad_norm,
    )

    curses.wrapper(
        run_scope_stream_ui,
        accession=args.accession,
        windows_tensor=windows_tensor,
        gc_values=metric,
        window_size=window_size,
        stride=stride,
        fps=args.fps,
        update_every=args.update_every,
        ctx=ctx,
    )
    return 0

def cmd_stream(args: argparse.Namespace) -> int:
    import random
    cfg = load_full_config(args.config)
    ncbi_cfg, train_cfg, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg); setup_logging(io_cfg.logs_dir)

    accessions = read_catalog(args.catalog)
    state = load_state(io_cfg.state_file)

    tok = _get_tok(args, train_cfg)
    frame = _get_frame(args, train_cfg)
    min_orf = _get_min_orf(args, train_cfg)
    window_size, stride = _pick_window_stride(args, train_cfg, tok)
    _validate_tok_params(tok, window_size, stride, frame)

    batch_size = args.batch_size or train_cfg.batch_size
    steps_per_plasmid = args.steps_per_plasmid or train_cfg.steps_per_plasmid
    max_epochs = args.max_epochs or train_cfg.max_stream_epochs

    epoch = int(state.get("epoch", 0))

    while epoch < max_epochs:
        indices = list(range(len(accessions)))
        if train_cfg.shuffle_catalog:
            random.shuffle(indices)

        for idx in indices:
            acc = accessions[idx]

            fasta_path = os.path.join(io_cfg.cache_fasta_dir, f"{acc}.fasta")
            if not os.path.exists(fasta_path):
                fetch_fasta(acc, io_cfg, ncbi_cfg, force=False)

            enc_path = encoded_cache_path(io_cfg, acc, tok, window_size, stride, frame, min_orf_aa=(min_orf if tok=="aa" else None))
            if os.path.exists(enc_path):
                encoded = np.load(enc_path)
            else:
                encoded = encode_accession(
                    acc, io_cfg, window_size, stride,
                    tokenizer=tok, frame_offset=frame, min_orf_aa=min_orf,
                    save_to_disk=True, out_path=enc_path
                )

            _ = train_on_encoded(
                acc, encoded,
                steps=steps_per_plasmid, batch_size=batch_size,
                state=state, io_cfg=io_cfg, train_cfg=train_cfg,
                tokenizer=tok, window_size_bp=window_size,
            )

            pvc = state["plasmid_visit_counts"]
            pvc[acc] = pvc.get(acc, 0) + 1
            state["current_index"] = idx
            state["epoch"] = epoch
            save_state(io_cfg.state_file, state)

            if args.delete_cache:
                cleanup_accession_files(acc, io_cfg, enc_path)

        epoch += 1

    print("[stream] Training complete.")
    return 0

def cmd_generate_plasmid(args: argparse.Namespace) -> int:
    cfg = load_full_config(args.config)
    _, train_cfg, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg); setup_logging(io_cfg.logs_dir)

    tok = _get_tok(args, train_cfg)
    if tok not in ("base", "codon"):
        raise ValueError("generate-plasmid supports tokenizer base|codon only (use generate-protein for aa).")

    window_size = args.window_size if args.window_size is not None else train_cfg.window_size
    stride = train_cfg.stride
    frame = _get_frame(args, train_cfg)
    _validate_tok_params(tok, int(window_size), int(stride), frame)

    seq = generate_plasmid_sequence(
        train_cfg=train_cfg,
        io_cfg=io_cfg,
        length_bp=args.length_bp,
        num_windows=args.num_windows,
        window_size_bp=int(window_size),
        seed=args.seed,
        latent_scale=args.latent_scale,
        temperature=args.temperature,
        gc_bias=args.gc_bias,
        name=args.name,
        output_path=args.output,
        tokenizer=tok,
    )
    print(f"[generate-plasmid] tokenizer={tok} wrote {len(seq)} bp -> {args.output}")
    return 0

def cmd_generate_protein(args: argparse.Namespace) -> int:
    cfg = load_full_config(args.config)
    _, train_cfg, io_cfg = extract_configs(cfg)
    ensure_dirs(io_cfg); setup_logging(io_cfg.logs_dir)

    tok = "aa"
    window_aa = args.window_aa if args.window_aa is not None else train_cfg.protein_window_aa

    seq = generate_protein_sequence(
        train_cfg=train_cfg,
        io_cfg=io_cfg,
        length_aa=args.length_aa,
        num_windows=args.num_windows,
        window_aa=int(window_aa),
        seed=args.seed,
        latent_scale=args.latent_scale,
        temperature=args.temperature,
        name=args.name,
        output_path=args.output,
    )
    print(f"[generate-protein] wrote {len(seq)} aa -> {args.output}")
    return 0

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="stream_train.py", description="Genostream streaming VAE trainer + scope.")
    p.add_argument("--config", default="stream_config.yaml", help="YAML config path (default: stream_config.yaml)")
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("init"); s.set_defaults(func=cmd_init)
    s = sub.add_parser("catalog-show"); s.add_argument("path"); s.set_defaults(func=cmd_catalog_show)

    s = sub.add_parser("fetch-one")
    s.add_argument("accession"); s.add_argument("--force", action="store_true")
    s.set_defaults(func=cmd_fetch_one)

    def add_tok_args(sp):
        sp.add_argument("--tokenizer", choices=["base","codon","aa"], default=None, help="Override tokenizer (default from config)")
        sp.add_argument("--frame-offset", type=int, choices=[0,1,2], default=None, help="Codon frame offset (default from config)")
        sp.add_argument("--min-orf-aa", type=int, default=None, help="AA tokenizer: minimum ORF length in amino acids (default from config)")

    s = sub.add_parser("encode-one")
    s.add_argument("accession")
    s.add_argument("--window-size", type=int, default=None)
    s.add_argument("--stride", type=int, default=None)
    add_tok_args(s)
    s.set_defaults(func=cmd_encode_one)

    s = sub.add_parser("train-one")
    s.add_argument("accession")
    s.add_argument("--steps", type=int, default=None)
    s.add_argument("--batch-size", type=int, default=None)
    s.add_argument("--window-size", type=int, default=None)
    s.add_argument("--stride", type=int, default=None)
    s.add_argument("--reencode", action="store_true")
    add_tok_args(s)
    s.set_defaults(func=cmd_train_one)

    s = sub.add_parser("scope-one")
    s.add_argument("accession")
    s.add_argument("--window-size", type=int, default=None)
    s.add_argument("--stride", type=int, default=None)
    s.add_argument("--fps", type=float, default=12.0)
    s.add_argument("--reencode", action="store_true")
    add_tok_args(s)
    s.set_defaults(func=cmd_scope_one)

    s = sub.add_parser("scope-stream")
    s.add_argument("accession")
    s.add_argument("--steps", type=int, default=None)
    s.add_argument("--batch-size", type=int, default=None)
    s.add_argument("--window-size", type=int, default=None)
    s.add_argument("--stride", type=int, default=None)
    s.add_argument("--fps", type=float, default=12.0)
    s.add_argument("--update-every", type=int, default=5)
    s.add_argument("--reencode", action="store_true")
    add_tok_args(s)
    s.set_defaults(func=cmd_scope_stream)

    s = sub.add_parser("stream")
    s.add_argument("--catalog", required=True)
    s.add_argument("--max-epochs", type=int, default=None)
    s.add_argument("--steps-per-plasmid", type=int, default=None)
    s.add_argument("--batch-size", type=int, default=None)
    s.add_argument("--window-size", type=int, default=None)
    s.add_argument("--stride", type=int, default=None)
    s.add_argument("--delete-cache", action="store_true")
    add_tok_args(s)
    s.set_defaults(func=cmd_stream)

    s = sub.add_parser("generate-plasmid")
    s.add_argument("--length-bp", type=int, default=10000)
    s.add_argument("--num-windows", type=int, default=None)
    s.add_argument("--window-size", type=int, default=None)
    s.add_argument("--name", default="genostream_plasmid_1")
    s.add_argument("--output", default="generated/novel_plasmid.fasta")
    s.add_argument("--seed", type=int, default=None)
    s.add_argument("--latent-scale", type=float, default=1.0)
    s.add_argument("--temperature", type=float, default=1.0)
    s.add_argument("--gc-bias", type=float, default=1.0)
    add_tok_args(s)
    s.set_defaults(func=cmd_generate_plasmid)

    s = sub.add_parser("generate-protein")
    s.add_argument("--length-aa", type=int, default=600)
    s.add_argument("--num-windows", type=int, default=None)
    s.add_argument("--window-aa", type=int, default=None)
    s.add_argument("--name", default="genostream_protein_1")
    s.add_argument("--output", default="generated/novel_protein.faa")
    s.add_argument("--seed", type=int, default=None)
    s.add_argument("--latent-scale", type=float, default=1.0)
    s.add_argument("--temperature", type=float, default=1.0)
    s.set_defaults(func=cmd_generate_protein)

    return p

def main(argv: Any = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)

if __name__ == "__main__":
    raise SystemExit(main())
